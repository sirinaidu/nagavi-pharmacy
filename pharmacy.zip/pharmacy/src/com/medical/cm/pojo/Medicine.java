package com.medical.cm.pojo;

import java.util.Date;

public class Medicine {
	private int id;
	private String name;
	private String batch_code;
	private String type;
	private int ItemsPerStrip;//quantity
	private Date expiry_date;
	private float BuyingPrice;
	private float SellingPrice;
	
	public Date getExpiry_date() {
		return expiry_date;
	}
	public void setExpiry_date(Date expiry_date) {
		this.expiry_date = expiry_date;
	}
	public String getBatch_code() {
		return batch_code;
	}
	public void setBatch_code(String batch_code) {
		this.batch_code = batch_code;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getItemsPerStrip() {
		return ItemsPerStrip;
	}
	public void setItemsPerStrip(int ItemsPerStrip) {
		this.ItemsPerStrip = ItemsPerStrip;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getBuyingPrice() {
		return BuyingPrice;
	}
	public void setBuyingPrice(float BuyingPrice) {
		this.BuyingPrice = BuyingPrice;
	}
	public float getSellingPrice() {
		return SellingPrice;
	}
	public void setSellingPrice(float SellingPrice) {
		this.SellingPrice = SellingPrice;
	}
	
	
	
}
