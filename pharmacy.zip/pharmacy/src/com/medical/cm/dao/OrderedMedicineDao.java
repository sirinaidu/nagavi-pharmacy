package com.medical.cm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ArrayList;
import java.util.List;

import com.medical.cm.pojo.AppException;
import com.medical.cm.pojo.Order;
import com.medical.cm.pojo.OrderedMedicine;
import com.medical.cm.dao.ConnectionManager;

public class OrderedMedicineDao {

	public void insertOrderedMeds(int medId, int units, int order_id) throws AppException {
		PreparedStatement statement = null;
		Connection connection = null;

		try {
			connection = ConnectionManager.getConnection();
			statement = connection.prepareStatement("insert into assignment.ordered_medicines (orderedmedicine_order_id,orderedmedicine_medicine_id,orderedmedicine_units) values(?,?,?)");
			statement.setInt(1, order_id);
			statement.setInt(2, medId);
			statement.setInt(3, units);
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new AppException("Error while inserting bill data.\n" + e.getMessage());
		} finally {
			try {

				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				throw new AppException("Error when closing connection.\n" + e.getMessage());
			}
		}

	}
	@SuppressWarnings("null")
	public  List<OrderedMedicine> getOrdered_Medicines() throws AppException{
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		List<Order> orders = new ArrayList<Order>();
		List<OrderedMedicine> ordermeds=null;;
		try {

			connection = ConnectionManager.getConnection();

			statement = connection.prepareStatement("select * FROM assignment.ordered_medicines");

			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				OrderedMedicine ordermedicine = new OrderedMedicine();
				ordermedicine.setUnits(resultSet.getInt("orderedmedicine_units"));

				ordermeds.add(ordermedicine);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new AppException("Error while getting the user data.\n" + e.getMessage());
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();

				}
				if (statement != null) {

					statement.close();

				}
				if (connection != null) {

					connection.close();

				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new AppException("Error while the closing connection.\n" + e.getMessage());
			}

		}
		return ordermeds;
		
	}


}
