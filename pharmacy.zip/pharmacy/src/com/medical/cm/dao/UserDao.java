package com.medical.cm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.medical.cm.pojo.AppException;
import com.medical.cm.pojo.User;

public class UserDao {
	public User getUser(String userName) throws AppException {
		ResultSet resultSet = null;
		PreparedStatement statement = null;
		Connection connection = null;
		User user = null;

		try {
			connection = ConnectionManager.getConnection();
			String query = "select * from user where user_name=?";
			statement = connection.prepareStatement(query);
			statement.setString(1, userName);
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				user = new User();
				user.setUserName(resultSet.getString("user_name"));
				user.setPassword(resultSet.getString("user_password"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new AppException("Error when getting user data.\n" + e.getMessage());
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				throw new AppException("Error when closing connection.\n" + e.getMessage());
			}
		}
		return user;
	}

}
