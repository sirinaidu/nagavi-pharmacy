package com.medical.cm.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.*;

import com.medical.cm.pojo.AppException;
import com.medical.cm.pojo.Medicine;

public class MedicineDao {
	
	Connection con = null;
	PreparedStatement ps = null;

	private Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment", "root", "root");
		}

		catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
	}

	public ArrayList<Medicine> getMedicines(String search) throws AppException {
		final String GET_ALL_MEDICINES = "SELECT * FROM medicine_Details";
			ResultSet resultSet = null;
			PreparedStatement statement = null;
			Connection connection = null;
			Medicine medicine = null;
			ArrayList<Medicine> medicines=new ArrayList<Medicine>();

		try {
			connection = ConnectionManager.getConnection();

			statement = connection.prepareStatement(GET_ALL_MEDICINES);

		

			resultSet = statement.executeQuery();
			while(resultSet.next()) {

				medicine = new Medicine();
				medicine.setId(resultSet.getInt("medicine_id"));
				medicine.setName(resultSet.getString("medicine_name"));
				medicine.setBatch_code(resultSet.getString("batch_code"));
				medicine.setType(resultSet.getString("medicine_type"));
				medicine.setItemsPerStrip(resultSet.getInt("items_per_strip"));
				medicine.setExpiry_date(resultSet.getDate("expiry_date"));
				medicine.setBuyingPrice(resultSet.getFloat("buying_price"));
				medicine.setSellingPrice(resultSet.getFloat("selling_price"));
				medicines.add(medicine);

			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new AppException("Error while getting medicines data.\n" + e.getMessage());
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}

			} catch (SQLException e) {
				throw new AppException("Error when closing connection.\n" + e.getMessage());
			}
		}
		return medicines;

	}
	public Medicine getMedicine(int cusID) {
		Medicine mPojo = null;

		try {
			con = getConnection();
			String sql = "SELECT * FROM  medicine_Details where  medicine_id=?";
			ps = con.prepareStatement(sql);
			ps.setInt(1,cusID);
			ResultSet result = ps.executeQuery();
			while (result.next()) {
				mPojo = new Medicine();
				mPojo.setId(result.getInt("medicine_id"));
				mPojo.setName(result.getString("medicine_name"));
				mPojo.setBatch_code(result.getString("batch_code"));
				mPojo.setType(result.getString("medicine_type"));
				mPojo.setItemsPerStrip(result.getInt("items_per_strip"));
				mPojo.setExpiry_date(result.getDate("expiry_date"));
				mPojo.setBuyingPrice(result.getFloat("buying_price"));
				mPojo.setSellingPrice(result.getFloat("selling_price"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return mPojo;
	}
	public void saveCustomer(Medicine mPojo) {
		Connection con = null;
		PreparedStatement ps = null;

		
			try {
				con = getConnection();
				String custInsertSql = "insert into medicine_Details values(?,?,?,?,?,?,?,?)";
				ps = con.prepareStatement(custInsertSql);
				ps.setInt(1, mPojo.getId());
				ps.setString(2, mPojo.getName());
				ps.setString(3, mPojo.getBatch_code());
				ps.setString(4, mPojo.getType());
				ps.setInt(5, mPojo.getItemsPerStrip());
				java.util.Date e=mPojo.getExpiry_date();
				java.sql.Date exp=new java.sql.Date(e.getTime());
				ps.setDate(6, exp);
				ps.setFloat(7, mPojo.getBuyingPrice());
				ps.setFloat(8, mPojo.getSellingPrice());
				ps.executeUpdate();
			}catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	public ArrayList<Medicine> sendDeails(int cusID) {
		Medicine m1Pojo = null;
		ArrayList<Medicine> medicines1=new ArrayList<Medicine>();


		try {
			con = getConnection();

			String sql = "SELECT * FROM medicine_Details where  medicine_id=?";

			ps = con.prepareStatement(sql);

			ps.setInt(1,cusID);

			ResultSet result = ps.executeQuery();

			while (result.next()) {
				m1Pojo = new Medicine();
				m1Pojo.setId(result.getInt("medicine_id"));
				m1Pojo.setName(result.getString("medicine_name"));
				m1Pojo.setBatch_code(result.getString("batch_code"));
				m1Pojo.setType(result.getString("medicine_type"));
				m1Pojo.setItemsPerStrip(result.getInt("items_per_strip"));
				m1Pojo.setExpiry_date(result.getDate("expiry_date"));
				m1Pojo.setBuyingPrice(result.getFloat("buying_price"));
				m1Pojo.setSellingPrice(result.getFloat("selling_price"));
				medicines1.add(m1Pojo);

			} 
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return medicines1;
	}
	public void deleteDetails(int cusID) {
		try {
			con = getConnection();
			String deleteCustomerSql = "delete  FROM medicine_Details where medicine_id=?";
			ps = con.prepareStatement(deleteCustomerSql);
			ps.setInt(1, cusID);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public List<Medicine> listMedicines() {

		List<Medicine> medicin = new ArrayList<Medicine>();
		Medicine m1Pojo = null;

		try {
			con = getConnection();
			String sql = "SELECT * FROM medicine_Details";

			ps = con.prepareStatement(sql);
			ResultSet result = ps.executeQuery(sql);

			while (result.next()) {
				m1Pojo = new Medicine();
				m1Pojo.setId(result.getInt("medicine_id"));
				m1Pojo.setName(result.getString("medicine_name"));
				m1Pojo.setBatch_code(result.getString("batch_code"));
				m1Pojo.setType(result.getString("medicine_type"));
				m1Pojo.setItemsPerStrip(result.getInt("items_per_strip"));
				m1Pojo.setExpiry_date(result.getDate("expiry_date"));
				m1Pojo.setBuyingPrice(result.getFloat("buying_price"));
				m1Pojo.setSellingPrice(result.getFloat("selling_price"));
				medicin.add(m1Pojo);



			} 

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return medicin;

	}
	public void editCustomer(Medicine mPojo) {
		Connection con = null;
		PreparedStatement ps = null;
		try {
			con = getConnection();
			String updateCustomer = "UPDATE medicine_Details SET medicine_name=?,batch_code=?,medicine_type=?,items_per_strip=?,expiry_date=?,buying_price=?,selling_price=? WHERE medicine_id=?";
			ps = con.prepareStatement(updateCustomer);
			ps.setInt(1, mPojo.getId());
			ps.setString(2, mPojo.getName());
			ps.setString(3, mPojo.getBatch_code());
			ps.setString(4, mPojo.getType());
			ps.setInt(5, mPojo.getItemsPerStrip());
			java.util.Date e=mPojo.getExpiry_date();
			java.sql.Date exp=new java.sql.Date(e.getTime());
			ps.setDate(6, exp);
			ps.setFloat(7, mPojo.getBuyingPrice());
			ps.setFloat(8, mPojo.getSellingPrice());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	public ArrayList<Medicine> getMedicinebyname(String search) throws AppException {
		final String GET_MEDICINE_BY_NAME = "SELECT * FROM medicine_Details where medicine_name=?";
			ResultSet resultSet = null;
			PreparedStatement statement = null;
			Connection connection = null;
			Medicine medicine = null;
			ArrayList<Medicine> medicines=new ArrayList<Medicine>();

		try {
			connection = ConnectionManager.getConnection();

			statement = connection.prepareStatement(GET_MEDICINE_BY_NAME);

			statement.setString(1, search);


			resultSet = statement.executeQuery();
			while(resultSet.next()) {

				medicine = new Medicine();
				medicine.setId(resultSet.getInt("medicine_id"));
				medicine.setName(resultSet.getString("medicine_name"));
				medicine.setBatch_code(resultSet.getString("batch_code"));
				medicine.setType(resultSet.getString("medicine_type"));
				medicine.setItemsPerStrip(resultSet.getInt("items_per_strip"));
				medicine.setExpiry_date(resultSet.getDate("expiry_date"));
				medicine.setBuyingPrice(resultSet.getFloat("buying_price"));
				medicine.setSellingPrice(resultSet.getFloat("selling_price"));
				medicines.add(medicine);

			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new AppException("Error while getting medicines data.\n" + e.getMessage());
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}

			} catch (SQLException e) {
				throw new AppException("Error when closing connection.\n" + e.getMessage());
			}
		}
		return medicines;

	}
	

}
