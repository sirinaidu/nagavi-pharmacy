package com.medical.cm.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.medical.cm.dao.OrderDao;
import com.medical.cm.dao.OrderedMedicineDao;
import com.medical.cm.pojo.AppException;
import com.medical.cm.pojo.Order;
import com.medical.cm.pojo.OrderedMedicine;
import com.medical.cm.pojo.User;
import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;


@WebServlet("/CreatingBill")
public class CreatingBill extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public CreatingBill() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String error = "";
		Order order = new Order();
		OrderedMedicine orderedMedicines = new OrderedMedicine();


		order.setPatientName(request.getParameter("patientName"));
		order.setDoctorName(request.getParameter("doctorName"));
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			order.setDate(sdf.parse(request.getParameter("date")));
		} catch (ParseException | java.text.ParseException e) {
			error = "Invalid date format";
			RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
			rd.forward(request, response);
			e.printStackTrace();
		}

		String[] quantitiesArray = request.getParameterValues("medicineQuantity");
		String[] pricesArray = request.getParameterValues("price");
		String[] medicineIdsArray = request.getParameterValues("medicineId");
		String[] medicinesArray = request.getParameterValues("medicineName");
		ArrayList<Float> priceList = new ArrayList<Float>();
		ArrayList<Integer> quantityList = new ArrayList<Integer>();
		ArrayList<Integer> medicineIdList = new ArrayList<Integer>();

		for (String unit : quantitiesArray) {
			quantityList.add(Integer.parseInt(unit));
		}
		for (String priceString : pricesArray) {
			priceList.add(Float.parseFloat(priceString));
		}
		for (String medId : medicineIdsArray) {
			medicineIdList.add(Integer.parseInt(medId));
		}
		float price = 0;
		for (Float amount : priceList) {
			price = price + amount;
		}
		order.setPrice(price);
		/*User currentUser = (User) request.getSession().getAttribute("user");
		order.setUser(currentUser);*/
		OrderDao orderDao = new OrderDao();


		try {
			orderDao.insertBill(order);

		} catch (AppException e) {
			e.printStackTrace();
		}
		OrderedMedicineDao orderedMedsDao = new OrderedMedicineDao();


		for (int i = 0; i < medicineIdList.size(); i++) {

			int medId = medicineIdList.get(i);
			int units = quantityList.get(i);
			int order_id = 0;

			try {

				order_id = orderDao.getRecentOrder();

				orderedMedsDao.insertOrderedMeds(medId, units, order_id);
			} catch (AppException e) {
				error = "Error while creating a bill.";
				e.printStackTrace();
			}

			request.setAttribute("orderId", order_id);
			request.setAttribute("order", order);
			request.setAttribute("medicines", medicinesArray);
			request.setAttribute("units", quantityList);
			request.setAttribute("prices", priceList);
			RequestDispatcher rd = request.getRequestDispatcher("generatedBill.jsp");
			rd.forward(request, response);
		}

	}

	}


