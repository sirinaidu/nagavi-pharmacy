package com.medical.cm.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.medical.cm.dao.OrderedMedicineDao;
import com.medical.cm.pojo.AppException;
import com.medical.cm.pojo.Medicine;
import com.medical.cm.pojo.OrderedMedicine;


@WebServlet("/ordered_medicine")
public class ordered_medicine extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ordered_medicine() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		OrderedMedicineDao omdao=new OrderedMedicineDao();
		OrderedMedicine ompojo=new OrderedMedicine();
		List<OrderedMedicine> om = null;
		try {
			om = omdao.getOrdered_Medicines();
		} catch (AppException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setAttribute("om", om);
		RequestDispatcher rd = request.getRequestDispatcher("ViewBillsAcc2Order.jsp");
		rd.forward(request, response);
	
	
	
	
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
