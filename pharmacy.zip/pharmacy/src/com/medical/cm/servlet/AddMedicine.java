package com.medical.cm.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.medical.cm.dao.MedicineDao;
import com.medical.cm.pojo.Medicine;


@WebServlet("/AddMedicine")
public class AddMedicine extends HttpServlet {
	private static final long serialVersionUID = 1L;
	RequestDispatcher rd = null;

   
    public AddMedicine() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		
	
		MedicineDao mDao = new MedicineDao();
		int id = Integer.parseInt(request.getParameter("medicineId"));
		String mname = request.getParameter("medicineName");
		String bc = request.getParameter("batch_code");
		String mtype = request.getParameter("medicineType");
		int items = Integer.parseInt(request.getParameter("items"));
		Date exp=null;
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		try {
			exp=sdf.parse(request.getParameter("expiry_date"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Float bp = Float.parseFloat(request.getParameter("cp"));

		Float sp = Float.parseFloat(request.getParameter("sp"));

		Medicine mPojo=new Medicine();
		mPojo.setId(id);
		mPojo.setName(mname);
		mPojo.setBatch_code(bc);
		mPojo.setType(mtype);
		mPojo.setItemsPerStrip(items);
		mPojo.setExpiry_date(exp);
		mPojo.setBuyingPrice(bp);
		mPojo.setSellingPrice(sp);
		mDao.saveCustomer(mPojo);
		List<Medicine> medicines = mDao.listMedicines();
		request.setAttribute("medicines", medicines);
		rd = request.getRequestDispatcher("medicineDetails.jsp");
		rd.forward(request, response);
		
	}

}
