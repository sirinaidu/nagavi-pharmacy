package com.medical.cm.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.medical.cm.pojo.AppException;
import com.medical.cm.pojo.Order;
import com.medical.cm.dao.ConnectionManager;
import com.medical.cm.pojo.User;
 

public class OrderDao {
	
	
	public List<Order> getOrders() throws AppException{
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		List<Order> orders = new ArrayList<Order>();
		try {

			connection = ConnectionManager.getConnection();

			statement = connection.prepareStatement("select * FROM assignment.order");

			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				Order order = new Order();
				order.setId(resultSet.getInt("order_id"));
				order.setDate(resultSet.getDate("order_date"));
				order.setPatientName(resultSet.getString("order_patient_name"));
				order.setDoctorName(resultSet.getString("order_doctor_name"));
				order.setPrice(resultSet.getFloat("order_price"));
				orders.add(order);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new AppException("Error while getting the user data.\n" + e.getMessage());
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();

				}
				if (statement != null) {

					statement.close();

				}
				if (connection != null) {

					connection.close();

				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new AppException("Error while the closing connection.\n" + e.getMessage());
			}

		}
		return orders;
		
	}



	public Order getOrder(int id) throws AppException {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		Order order=null;

		try {
			connection = ConnectionManager.getConnection();
			statement = connection.prepareStatement("SELECT * FROM assignment.order where order_id = ?");
			statement.setInt(1, id);
			resultSet = statement.executeQuery();

			if (resultSet.next()) {
				order = new Order();
				order.setId(resultSet.getInt("order_id"));
				order.setDate(resultSet.getDate("order_date"));
				order.setPatientName(resultSet.getString("order_patient_name"));

				order.setDoctorName(resultSet.getString("order_doctor_name"));
				order.setPrice(resultSet.getFloat("order_price"));

			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new AppException("Error while getting the bill data.\n" + e.getMessage());
		} finally {
			try {
				if (resultSet != null) {
				resultSet.close();
				}
				if (statement != null) {

				statement.close();
				}
				if (connection != null) {

					connection.close();
			}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new AppException("Error while the closing connection.\n" + e.getMessage());
			}
		}
	return order;
	}
	
	public List<Order> getOrdersFromDates(String fromDate, String toDate,String orderby) throws AppException {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		List<Order> orders = new ArrayList<Order>();
		try {
			connection = ConnectionManager.getConnection();
			statement = connection.prepareStatement("SELECT * FROM assignment.order where (order_date between ? and ?) order by ?");
			statement.setString(1, fromDate);
			statement.setString(2, toDate);
			statement.setString(3, orderby);

			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				Order order = new Order();
				order.setId(resultSet.getInt("order_id"));
				order.setDate(resultSet.getDate("order_date"));
				order.setPatientName(resultSet.getString("order_patient_name"));
				order.setDoctorName(resultSet.getString("order_doctor_name"));
				order.setPrice(resultSet.getFloat("order_price"));
				orders.add(order);

			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new AppException("Error while getting the bill data.\n" + e.getMessage());
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (statement != null) {

					statement.close();
				}
				if (connection != null) {

					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new AppException("Error while the closing connection.\n" + e.getMessage());
			}
		}
		return orders;
	}
	public void insertBill(Order order) throws AppException {

		PreparedStatement ps = null;
		Connection connection = null;


		try {
			connection = ConnectionManager.getConnection();
			ps = connection.prepareStatement("INSERT into assignment.order(order_date, order_patient_name, order_doctor_name, order_price)VALUES (?, ?, ?, ?)");

			Date date = new Date(order.getDate().getTime());

			ps.setDate(1, date);

			ps.setString(2, order.getPatientName());

			ps.setString(3, order.getDoctorName());
			ps.setFloat(4, order.getPrice());

			ps.executeUpdate();


		} catch (SQLException e) {
			e.printStackTrace();
			throw new AppException("Error while inserting bill data.\n" + e.getMessage());
		} finally {
			try {

				if (ps != null) {
					ps.close();
				}
				if (ps != null) {
					connection.close();
				}
			} catch (SQLException e) {
				throw new AppException("Error when closing connection.\n" + e.getMessage());
			}
		}
	}
	public int getRecentOrder() throws AppException {
		int orderId = 0;
		PreparedStatement statement = null;
		Connection connection = null;
		ResultSet resultSet = null;
		try {
			connection = ConnectionManager.getConnection();
			statement = connection.prepareStatement("select max(order_id) from assignment.order");
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				orderId = resultSet.getInt("max(order_id)");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new AppException("Error while getting the bill data.\n" + e.getMessage());
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();

				}
				if (statement != null) {

					statement.close();

				}
				if (connection != null) {

					connection.close();

				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new AppException("Error while the closing connection.\n" + e.getMessage());
			}

		}

		return orderId;
	}

}


