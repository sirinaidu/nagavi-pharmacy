package com.medical.cm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.medical.cm.pojo.AppException;
import com.medical.cm.pojo.User;

public class UserDao {
	public void addUser(User u){
		Connection con = null;
		PreparedStatement ps = null;
	try {
		con = ConnectionManager.getConnection();
		String custInsertSql = "insert into user(name,contact,username,password)values(?,?,?,?)";
		ps = con.prepareStatement(custInsertSql);
		
		ps.setString(1, u.getName());
		ps.setString(2, u.getContact());
		ps.setString(3, u.getUserName());
		ps.setString(4, u.getPassword());
		ps.executeUpdate();
	}catch (SQLException e) {
	e.printStackTrace();
} catch (Exception e) {
	e.printStackTrace();
} finally {
	try {
		if (ps != null) {
			ps.close();
		}
		if (con != null) {
			con.close();
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
}

}
	public User getUser(String userName) throws AppException {
		ResultSet resultSet = null;
		PreparedStatement statement = null;
		Connection connection = null;
		User user = null;

		try {
			connection = ConnectionManager.getConnection();
			String query = "select username, password from user where username=?";
			statement = connection.prepareStatement(query);
			statement.setString(1, userName);
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				user = new User();
				user.setUserName(resultSet.getString("username"));
				user.setPassword(resultSet.getString("password"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new AppException("Error when getting user data.\n" + e.getMessage());
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				throw new AppException("Error when closing connection.\n" + e.getMessage());
			}
		}
		return user;
	}

}
