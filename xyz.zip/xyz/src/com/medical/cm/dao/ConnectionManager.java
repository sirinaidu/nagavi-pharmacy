package com.medical.cm.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.medical.cm.pojo.AppException;

public class ConnectionManager {
	public static Connection getConnection() throws AppException {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			throw new AppException("Error when loading JDBC driver.\n" + e.getMessage());
		}
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment", "root", "root");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

}
