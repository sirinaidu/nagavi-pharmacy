package com.medical.cm.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.medical.cm.dao.UserDao;
import com.medical.cm.pojo.User;


@WebServlet("/AddUser")
public class AddUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
	RequestDispatcher rd = null;

   
    public AddUser() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		
	
		UserDao uDao = new UserDao();
		String name = request.getParameter("name");
		String contact = request.getParameter("contact");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		

		User u=new User();
		u.setName(name);
		u.setContact(contact);
		u.setUserName(username);
		u.setPassword(password);
		uDao.addUser(u);
//		List<Medicine> medicines = mDao.listMedicines();
//		request.setAttribute("medicines", medicines);
	rd = request.getRequestDispatcher("home1.jsp");
	rd.forward(request, response);
		
	}

}
