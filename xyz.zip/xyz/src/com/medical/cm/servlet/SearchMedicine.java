package com.medical.cm.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.medical.cm.pojo.AppException;
import com.medical.cm.pojo.Medicine;
import com.medical.cm.dao.MedicineDao;


public class SearchMedicine extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public SearchMedicine() {
        super();
       
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String error="";
		String forwardUrl = "medicineDetails.jsp";
		String search = request.getParameter("search");

		MedicineDao medicineDao=new MedicineDao();
		
		try {
			ArrayList<Medicine> medicines = medicineDao.getMedicines(search);
			request.setAttribute("medicines", medicines);

		} catch (AppException e) {
			e.printStackTrace();
			error="No Medicines found with that name!";
			forwardUrl = "home.jsp";
		}
		request.setAttribute("error", error);
		RequestDispatcher rd = request.getRequestDispatcher(forwardUrl);
		rd.forward(request, response);
	
	
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		String error="";
		String forwardUrl = "ViewMedicine.jsp";
		String search = request.getParameter("search");

		MedicineDao medicineDao=new MedicineDao();
		
		try {
			ArrayList<Medicine> medicines = medicineDao.getMedicinebyname(search);
			request.setAttribute("medicines", medicines);

		} catch (AppException e) {
			e.printStackTrace();
			error="No Medicines found with that name!";
			forwardUrl = "home.jsp";
		}
		request.setAttribute("error", error);
		RequestDispatcher rd = request.getRequestDispatcher(forwardUrl);
		rd.forward(request, response);
	}
}
	


