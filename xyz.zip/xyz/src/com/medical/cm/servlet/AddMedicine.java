package com.medical.cm.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.medical.cm.dao.MedicineDao;
import com.medical.cm.pojo.Medicine;


@WebServlet("/AddMedicine")
public class AddMedicine extends HttpServlet {
	private static final long serialVersionUID = 1L;
	RequestDispatcher rd = null;

   
    public AddMedicine() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		
	
		MedicineDao mDao = new MedicineDao();
		int id = Integer.parseInt(request.getParameter("id"));
		String mname = request.getParameter("medicine_name");
		String mc=request.getParameter("medicine_code");
		String bc=request.getParameter("batch_code");
		String mtype = request.getParameter("medicine_type");
		String weight = request.getParameter("weight");
				Float bp = Float.parseFloat(request.getParameter("price"));
				String ref=request.getParameter("refrigiration");

		Medicine mPojo=new Medicine();
		mPojo.setId(id);
		mPojo.setMedicinename(mname);
		mPojo.setBatchcode(bc);
		mPojo.setMedicinetype(mtype);
		mPojo.setMedicinecode(mc);
		mPojo.setWeight(weight);
		mPojo.setPrice(bp);
		//mPojo.setSellingPrice(sp);
		mPojo.setRefrigiration(ref);
		mDao.saveCustomer(mPojo);
		List<Medicine> medicines = mDao.listMedicines();
		request.setAttribute("medicines", medicines);
		rd = request.getRequestDispatcher("medicineDetails.jsp");
		rd.forward(request, response);
		
	}

}
