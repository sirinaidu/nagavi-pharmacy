package com.medical.cm.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.medical.cm.pojo.Medicine;
import com.medical.cm.dao.MedicineDao;

public class Addition extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	RequestDispatcher rd = null;

    public Addition() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String actionPerformed = request.getParameter("ac");

		int mid = Integer.parseInt(request.getParameter("cid"));

		if(actionPerformed.equals("deleteCustomer"))
		{
			MedicineDao m1Dao = new MedicineDao();
			m1Dao.deleteDetails(mid);
			List<Medicine> medicines = m1Dao.listMedicines();
			request.setAttribute("medicines", medicines);
			rd = request.getRequestDispatcher("medicineDetails.jsp");
			rd.forward(request, response);
			
			
		}
		else if (actionPerformed.equals("editCustomer")) {
			MedicineDao m1Dao = new MedicineDao();
				Medicine medicines = m1Dao.getMedicine(mid);
				request.setAttribute("medicines", medicines);
				rd = request.getRequestDispatcher("editMedicine.jsp");
				rd.forward(request, response);
			}
		else if (actionPerformed.equals("searchmedicine")) {

			MedicineDao m1Dao = new MedicineDao();
			Medicine medicines = m1Dao.getMedicine(mid);
			request.setAttribute("medicines", medicines);
			rd = request.getRequestDispatcher("editMedicine.jsp");
			rd.forward(request, response);
		}
		
	
	else
	{
		MedicineDao m1Dao = new MedicineDao();

		List<Medicine> medicines = m1Dao.listMedicines();
		request.setAttribute("medicines", medicines);
		rd = request.getRequestDispatcher("medicineDetails.jsp");
		rd.forward(request, response);
		
		
	}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String actionPerformed = request.getParameter("ac");

		MedicineDao mDao = new MedicineDao();
		int id = Integer.parseInt(request.getParameter("id"));
		String mname = request.getParameter("medicine_name");
		String mc=request.getParameter("medicine_code");
		String bc=request.getParameter("batch_code");
		String mtype = request.getParameter("medicine_type");
		String weight = request.getParameter("weight");
				Float bp = Float.parseFloat(request.getParameter("price"));
				String ref=request.getParameter("refrigiration");
		//Float sp = Float.parseFloat(request.getParameter("sp"));

		Medicine mPojo=new Medicine();
		mPojo.setId(id);
		mPojo.setMedicinename(mname);
		mPojo.setBatchcode(bc);
		mPojo.setMedicinetype(mtype);
		mPojo.setMedicinecode(mc);
		mPojo.setWeight(weight);
		mPojo.setPrice(bp);
		//mPojo.setSellingPrice(sp);
		mPojo.setRefrigiration(ref);

		if (actionPerformed.equals("editCustomer")) {

			mDao.editCustomer(mPojo);
			MedicineDao m1Dao = new MedicineDao();
			List<Medicine> medicines = m1Dao.listMedicines();
			request.setAttribute("medicines", medicines);
			rd = request.getRequestDispatcher("medicineDetails.jsp");
			rd.forward(request, response);
		}
		
		
}

}
