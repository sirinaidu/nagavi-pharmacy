package com.medical.cm.pojo;

public class AppException extends Exception {
	public AppException(String errorMessage) {
		super(errorMessage);
	}
}
